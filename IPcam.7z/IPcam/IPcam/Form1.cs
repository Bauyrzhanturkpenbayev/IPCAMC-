﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;

namespace IPcam
{
    public partial class Form1 : Form
    {
        MJPEGStream stream;
        public Form1()
        {
            InitializeComponent();
            stream = new MJPEGStream("http://192.168.43.1:8080/video");
            stream.NewFrame += stream_NewFrame;
        }

        void stream_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap bmp = (Bitmap)eventArgs.Frame.Clone();
            streamBox.Image = bmp;
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            stream.Start();
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            stream.Stop();
        }
    }
}
